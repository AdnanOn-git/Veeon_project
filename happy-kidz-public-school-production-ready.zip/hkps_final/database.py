"""
database.py
Handles SQLite connection and schema initialization for
Happy Kidz Public School - School Management System.
"""

import sqlite3
from werkzeug.security import generate_password_hash
import os
import secrets

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "school.db")

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('admin','teacher','student')),
    linked_id INTEGER,
    is_active INTEGER DEFAULT 1,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    class_name TEXT NOT NULL,
    section TEXT NOT NULL,
    UNIQUE(class_name, section)
);

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_uid TEXT UNIQUE NOT NULL,
    admission_number TEXT,
    roll_number TEXT,
    full_name TEXT NOT NULL,
    class_id INTEGER,
    dob TEXT,
    gender TEXT,
    photo TEXT,
    blood_group TEXT,
    father_name TEXT,
    mother_name TEXT,
    guardian_name TEXT,
    parent_contact TEXT,
    alternate_phone TEXT,
    emergency_contact TEXT,
    aadhaar_number TEXT,
    sssm_id TEXT,
    family_id TEXT,
    category TEXT,
    caste TEXT,
    religion TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    pincode TEXT,
    family_annual_income TEXT,
    parent_occupation TEXT,
    medical_issues TEXT,
    bank_account_number TEXT,
    bank_ifsc TEXT,
    bank_name TEXT,
    bank_account_holder TEXT,
    previous_school TEXT,
    previous_class TEXT,
    admission_date TEXT,
    other_info TEXT,
    email TEXT,
    phone TEXT,
    status TEXT DEFAULT 'active',
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS teachers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    teacher_uid TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    subject TEXT,
    designation TEXT,
    qualification TEXT,
    email TEXT,
    phone TEXT,
    joining_date TEXT,
    address TEXT,
    emergency_contact TEXT,
    photo TEXT,
    status TEXT DEFAULT 'active',
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS exams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exam_name TEXT NOT NULL,
    academic_session TEXT,
    class_id INTEGER,
    exam_date TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS exam_subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    exam_id INTEGER NOT NULL,
    subject_id INTEGER NOT NULL,
    max_marks REAL NOT NULL DEFAULT 100,
    FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
    UNIQUE(exam_id, subject_id)
);

CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    exam_id INTEGER NOT NULL,
    subject_id INTEGER NOT NULL,
    marks_obtained REAL,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
    UNIQUE(student_id, exam_id, subject_id)
);

CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    class_id INTEGER,
    date TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('present','absent')),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    UNIQUE(student_id, date)
);

CREATE TABLE IF NOT EXISTS fees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    amount REAL NOT NULL,
    payment_status TEXT DEFAULT 'pending' CHECK(payment_status IN ('paid','pending','partial')),
    due_date TEXT,
    payment_date TEXT,
    receipt_number TEXT,
    remarks TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS timetable (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    class_id INTEGER NOT NULL,
    day_of_week TEXT NOT NULL,
    period_number INTEGER NOT NULL,
    subject_id INTEGER,
    teacher_id INTEGER,
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS social_links (
    id INTEGER PRIMARY KEY CHECK(id=1),
    instagram TEXT,
    youtube TEXT,
    facebook TEXT,
    whatsapp TEXT
);

CREATE TABLE IF NOT EXISTS site_settings (
    id INTEGER PRIMARY KEY CHECK(id=1),
    tagline TEXT,
    address TEXT,
    phone TEXT,
    email TEXT
);

CREATE TABLE IF NOT EXISTS gallery_albums (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    event_date TEXT,
    description TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS gallery_photos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    album_id INTEGER NOT NULL,
    photo_path TEXT NOT NULL,
    caption TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (album_id) REFERENCES gallery_albums(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT,
    date TEXT DEFAULT (date('now')),
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    event_date TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS admissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_name TEXT NOT NULL,
    parent_name TEXT,
    email TEXT,
    phone TEXT,
    class_applied TEXT,
    message TEXT,
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT,
    message TEXT,
    created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS question_papers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    class_id INTEGER,
    subject_id INTEGER,
    exam_id INTEGER,
    academic_session TEXT,
    total_marks REAL,
    duration TEXT,
    instructions TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (class_id) REFERENCES classes(id) ON DELETE SET NULL,
    FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE SET NULL,
    FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question_paper_id INTEGER NOT NULL,
    question_type TEXT NOT NULL,
    question_text TEXT NOT NULL,
    marks REAL NOT NULL DEFAULT 1,
    order_index INTEGER DEFAULT 0,
    FOREIGN KEY (question_paper_id) REFERENCES question_papers(id) ON DELETE CASCADE
);
"""

DEFAULT_SUBJECTS = [
    "English", "Mathematics", "Hindi", "Science", "Social Science",
    "Computer Science", "General Knowledge", "Drawing", "Physical Education"
]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    first_time = not os.path.exists(DB_PATH)
    conn = get_db()
    conn.executescript(SCHEMA)
    conn.execute("INSERT OR IGNORE INTO social_links (id) VALUES (1)")
    conn.execute("INSERT OR IGNORE INTO site_settings (id, tagline, address, phone, email) VALUES (1,?,?,?,?)", ("Where every child learns to think, build and lead.", "Bhimgarh", "", ""))

    # Seed the owner's admin account on first run. In production, supply
    # ADMIN_PASSWORD and optionally ADMIN_USERNAME in the server environment.
    existing_admin = conn.execute(
        "SELECT id FROM users WHERE role='admin' LIMIT 1"
    ).fetchone()
    if not existing_admin:
        admin_username = os.environ.get("ADMIN_USERNAME", "admin").strip() or "admin"
        admin_password = os.environ.get("ADMIN_PASSWORD", "")
        if not admin_password:
            admin_password = secrets.token_urlsafe(18)
            print("\n[HKPS] First admin account created.")
            print(f"[HKPS] Username: {admin_username}")
            print(f"[HKPS] Temporary password: {admin_password}")
            print("[HKPS] Change it immediately in Admin → Account Security.\n")
        conn.execute(
            "INSERT INTO users (username, password_hash, role) VALUES (?,?,?)",
            (admin_username, generate_password_hash(admin_password), "admin")
        )

    # Seed default subjects
    for s in DEFAULT_SUBJECTS:
        conn.execute(
            "INSERT OR IGNORE INTO subjects (subject_name) VALUES (?)", (s,)
        )

    # Seed a couple of default classes
    for cname in ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]:
        for sec in ["A"]:
            conn.execute(
                "INSERT OR IGNORE INTO classes (class_name, section) VALUES (?,?)",
                (cname, sec)
            )

    conn.commit()
    conn.close()
    return first_time
